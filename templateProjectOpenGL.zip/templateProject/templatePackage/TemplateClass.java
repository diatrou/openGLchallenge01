package templatePackage;

import com.jogamp.newt.event.WindowAdapter;
import com.jogamp.newt.event.WindowEvent;
import com.jogamp.newt.opengl.GLWindow;
import com.jogamp.opengl.GL2;
/*import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLContext; //new
import com.jogamp.opengl.GLEventListener;
import com.jogamp.opengl.GLProfile;*/
import com.jogamp.opengl.*; // Αντί των γραμμών 8 - 12
import com.jogamp.opengl.util.FPSAnimator;

public class TemplateClass implements GLEventListener{
	private static GLWindow window;
	
	public static void init() {
		GLProfile.initSingleton();
		GLProfile profile = GLProfile.get(GLProfile.GL2);
		GLCapabilities capabilities = new GLCapabilities(profile);
		window = GLWindow.create(capabilities);
		window.setSize(500, 500);
		window.setResizable(false);
		window.setVisible(true);
		window.addGLEventListener(new TemplateClass());
		
		window.addWindowListener(
				new WindowAdapter() {
					@Override
					public void windowDestroyNotify(WindowEvent e) {
						System.exit(0);
					}
				}
		);
		
		FPSAnimator animator = new FPSAnimator(window, 60);
		animator.start();
	}

	
	public static void main(String[] args) {
		init();
	}
	@Override
	public void display(GLAutoDrawable drawable) {
		GL2 gl = GLContext.getCurrentGL().getGL2();
//		gl.glClearColor(0, 0, 0, 1);  
//		gl.glClear(GL2.GL_COLOR_BUFFER_BIT); 
//		
//		gl.glColor3f(_, _, _);
//		gl.glBegin(GL2.___);
//			gl.glVertex2f(-0.5f, -0.5f);
//			gl.glVertex2f(0.5f, -0.5f);
//			gl.glVertex2f(0.5f, 0.5f);
//		gl.glEnd();		
	}
	@Override
	public void dispose(GLAutoDrawable drawable) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void init(GLAutoDrawable drawable) {
		// TODO Auto-generated method stub
		System.out.println("Initialized!");

	}
	@Override
	public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
		// TODO Auto-generated method stub
		
	}
	
}
